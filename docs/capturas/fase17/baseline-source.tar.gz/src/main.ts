import * as T from "three";
import "./ui/style.css";
import { applyQuality, qualityProfile } from "./render/quality";
import { textureBudget } from "./render/materials";
import { FrameMetrics } from "./render/metrics";
import { GpuTimer } from "./render/gpu-timer";
import { CinematicCamera } from "./engine/camera";
import { animateCharacter, animateDeath } from "./world/character";
import { Input } from "./engine/input";
import {
  World,
  character,
  names,
  subtitles,
  type Interactable,
} from "./world/scene";
import { fresh, clamp, move, type State } from "./systems/state";
import { Audio } from "./systems/audio";
import { notes } from "./world/narrative";
import { readSave, writeSave } from "./systems/save";
import { Combat } from "./systems/combat";
import { Sanity } from "./systems/sanity";
import { drinkTonic } from "./systems/inventory";
import { readSettings } from "./systems/config";
import { trapFocus } from "./ui/accessibility";
const app = document.querySelector<HTMLDivElement>("#app")!;
app.innerHTML = `<div id="viewport"></div><div id="veil"></div><div id="hit-feedback" aria-hidden="true"></div><div id="hud"><header><div class="brand">SANITY—404</div><div class="chapter"><div class="eyebrow" id="sub"></div><div class="location" id="location"></div></div></header><div class="bottom"><div class="vitals"><div class="eyebrow">ÉLISE MOREAU · RESTAURADORA</div><div class="stat"><span>SALUD</span><span id="hptext">100</span></div><div class="bar"><div id="health" class="fill"></div></div><div class="stat"><span>CORDURA</span><span id="sptext">100</span></div><div class="bar"><div id="sanity" class="fill"></div></div></div><div class="help">WASD / ↑↓←→ · MOVERSE<br>E · INTERACTUAR &nbsp; ESPACIO · ATACAR<br>F / LB · DEFENDER &nbsp; SHIFT · CORRER<br>TAB · INVENTARIO &nbsp; M · MAPA &nbsp; ESC · PAUSA</div></div></div><div id="prompt"></div><div id="toast" role="status" aria-live="polite"></div><div id="overlay" role="dialog" aria-modal="true" aria-label="Menú del juego"><div class="panel" id="panel"></div></div>`;
const el = (id: string) => document.getElementById(id)!;
trapFocus(el("overlay"));
let renderer: T.WebGLRenderer;
try {
  renderer = new T.WebGLRenderer({
    antialias: true,
    powerPreference: "high-performance",
  });
} catch {
  el("panel").innerHTML =
    "<h2>WebGL no está disponible</h2><p>Activa la aceleración gráfica del navegador para explorar SANITY-404.</p>";
  throw new Error("WebGL unavailable");
}
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.3));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = T.SRGBColorSpace;
renderer.toneMapping = T.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.35;
el("viewport").append(renderer.domElement);
const camera = new T.PerspectiveCamera(55, innerWidth / innerHeight, 0.1, 70),
  input = new Input(renderer.domElement),
  audio = new Audio(),
  cinematic = new CinematicCamera(),
  metrics = new FrameMetrics(),
  gpuTimer = import.meta.env.DEV ? new GpuTimer(renderer.domElement) : null;
let state: State = fresh(),
  world: World,
  player: T.Group,
  enemy: T.Group,
  corpse: T.Group,
  contact: T.Mesh[],
  threat: T.Mesh,
  corpseTime = 0,
  deathTime = 0,
  combat: Combat,
  sanity: Sanity,
  paused = true,
  started = false,
  yaw = 0,
  toastTime = 0,
  near: Interactable | undefined,
  settings = readSettings();
audio.setVolume(settings.volume);
applyQuality(renderer, settings.quality);

function toast(text: string) {
  el("toast").textContent = text;
  toastTime = 5;
}
function panel(html: string) {
  paused = true;
  audio.pause();
  input.clear();
  el("overlay").hidden = false;
  el("panel").innerHTML = html;
  el("panel").querySelector<HTMLButtonElement>("button")?.focus();
}
function button(id: string, fn: () => void) {
  el(id).onclick = fn;
}
renderer.domElement.tabIndex = 0;
function resume() {
  paused = false;
  el("overlay").hidden = true;
  input.clear();
  audio.resume();
  renderer.domElement.focus();
}
function loadRoom() {
  world?.dispose();
  world = new World(
    state.room,
    state.items,
    state.seals,
    state.read,
    state.collected,
    settings.quality,
  );
  player = character();
  player.position.set(state.x, 0, state.z);
  world.scene.add(player);
  enemy = character(true);
  enemy.position.set(3, 0, -3);
  enemy.visible = !state.defeated.includes("enemy" + state.room);
  world.scene.add(enemy);
  contact = [player, enemy].map((actor) => {
    const shadow = new T.Mesh(
      new T.PlaneGeometry(0.95, 0.7),
      new T.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        vertexShader:
          "varying vec2 v; void main(){v=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
        fragmentShader:
          "varying vec2 v; void main(){float a=1.-smoothstep(.05,.5,length(v-.5));gl_FragColor=vec4(.02,.025,.03,a*.32);}",
      }),
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.copy(actor.position).setY(0.025);
    shadow.visible = actor.visible;
    world.scene.add(shadow);
    return shadow;
  });
  threat = new T.Mesh(
    new T.RingGeometry(1.35, 1.39, 48),
    new T.MeshBasicMaterial({
      color: 0xcea36b,
      transparent: true,
      opacity: 0.12,
      depthWrite: false,
      side: T.DoubleSide,
    }),
  );
  threat.rotation.x = -Math.PI / 2;
  threat.visible = false;
  world.scene.add(threat);
  corpse = character(true);
  corpse.visible = false;
  world.scene.add(corpse);
  corpseTime = deathTime = 0;
  combat = new Combat(state.room);
  sanity = new Sanity(world);
  el("location").textContent = names[state.room];
  el("sub").textContent = subtitles[state.room];
  cinematic.update(
    camera,
    state.x,
    state.z,
    state.room,
    0,
    settings.reduced,
    world.obstacles,
    { mode: settings.cameraMode },
  );
}
function begin(s: State) {
  state = s;
  started = true;
  yaw = 0;
  loadRoom();
  void audio
    .start()
    .catch(() => toast("Audio no disponible; puedes continuar sin sonido."));
  resume();
  toast("Encuentra a Adrien. Empieza por la carta y la llave del vestíbulo.");
}

function menu() {
  panel(
    `<div class="ornament">ARCHIVO DE LAS AUSENCIAS · 1927</div><h1>SANITY—404</h1><div class="subtitle">LO QUE OLVIDAS TAMBIÉN TE RECUERDA</div><div class="rule"></div><p>Una carta de tu hermano desaparecido. Una casa que no existe.<br>Cinco lugares donde la memoria empieza a pudrirse.</p><div class="actions"><button id="new">Nueva partida</button><button id="load" ${readSave() ? "" : "disabled"}>Continuar</button>${started ? '<button id="resume">Volver</button>' : ""}<button id="settings">Opciones</button></div><p class="small">Experiencia breve de horror cósmico · auriculares recomendados<br>Teclado y ratón / mando estándar · recursos originales y audio sintetizado</p>`,
  );
  button("new", () => {
    if (started) {
      panel(
        '<h2>¿Comenzar de nuevo?</h2><p>Se perderá el progreso sin guardar. Tu partida guardada se conserva.</p><div class="actions"><button id="yes">Nueva partida</button><button id="no">Volver</button></div>',
      );
      button("yes", () => begin(fresh()));
      button("no", menu);
    } else begin(fresh());
  });
  button("load", () => {
    const s = readSave();
    if (s) begin(s);
    else toast("No hay una partida válida.");
  });
  button("settings", options);
  if (started) button("resume", resume);
}
function options() {
  panel(
    `<div class="eyebrow">AJUSTES DE LA EXPERIENCIA</div><h2>Un horror a tu medida</h2><label><input type="checkbox" id="reduced" ${settings.reduced ? "checked" : ""}> Reducir efectos psicológicos y movimiento de cámara</label><p class="small">Desactiva apariciones y variaciones de luz. No se utilizan destellos rápidos.</p><label>Volumen <input id="volume" type="range" min="0" max="1" step=".05" value="${settings.volume}"></label><label>Calidad gráfica <select id="quality"><option value="1">Baja</option><option value="1.3">Media</option><option value="1.6">Alta</option></select></label><label>Cámara <select id="camera-mode"><option value="classic">Clásica · encuadres por zona</option><option value="modern">Moderna · seguimiento cercano</option></select></label><p class="small">Movimiento con ejes estables en ambos modos. Mando: stick izquierdo mover · LB defender · A interactuar · B atacar · X tónico · Y inventario · Select mapa · Start pausa.<br>Cámara cinematográfica automática. Ratón: izquierdo para atacar.</p><div class="actions"><button id="back">Aplicar y volver</button></div>`,
  );
  (el("camera-mode") as HTMLSelectElement).value = settings.cameraMode;
  (el("quality") as HTMLSelectElement).value = String(settings.quality);
  button("back", () => {
    settings.cameraMode =
      (el("camera-mode") as HTMLSelectElement).value === "modern"
        ? "modern"
        : "classic";
    settings.reduced = (el("reduced") as HTMLInputElement).checked;
    settings.volume = Number((el("volume") as HTMLInputElement).value);
    settings.quality = Number((el("quality") as HTMLSelectElement).value);
    audio.setVolume(settings.volume);
    applyQuality(renderer, settings.quality);
    const enemyHealth = combat.health;
    loadRoom();
    combat.health = enemyHealth;
    try {
      localStorage.setItem("sanity404-settings", JSON.stringify(settings));
    } catch {
      toast("No se han podido conservar los ajustes.");
    }
    menu();
  });
}
function inventory() {
  panel(
    `<div class="eyebrow">PERTENENCIAS Y RECUERDOS</div><h2>Inventario</h2><p>Arma: bastón de fresno · golpes sin munición</p><p>${state.items.filter((i) => !i.startsWith("Tónico")).join(" · ") || "Todavía no has recogido objetos."}</p><p>Tónicos: ${state.items.filter((i) => i.startsWith("Tónico")).length} · Sellos: ${state.seals.length}/3</p><div class="actions"><button id="heal">Beber tónico</button><button id="close">Volver</button></div><h2>Documentos</h2>${state.read.map((i) => `<p><strong>${notes[Number(i)][0]}</strong><br>${notes[Number(i)][1]}</p>`).join("")}`,
  );
  button("close", resume);
  button("heal", () => {
    heal();
    inventory();
  });
}
function heal() {
  const result = drinkTonic(state);
  if (result === "empty") toast("No tienes tónicos.");
  else if (result === "full") toast("No necesitas un tónico ahora.");
  else {
    audio.tone(440, 0.5);
    toast("El pulso se estabiliza. +40 salud · +25 cordura");
  }
}
function interact(o: Interactable) {
  audio.tone(260);
  if (o.kind === "item") {
    state.items.push(o.value!);
    state.collected.push(o.value!);
    world.scene.remove(o.mesh!);
    world.objects = world.objects.filter((i) => i !== o);
    toast("Recogido: " + o.value);
  }
  if (o.kind === "note") {
    if (!state.read.includes(String(state.room))) {
      state.read.push(String(state.room));
      state.sanity = clamp(state.sanity - 4);
    }
    panel(
      `<div class="eyebrow">DOCUMENTO ${state.room + 1} / 5</div><h2>${notes[state.room][0]}</h2><p>${notes[state.room][1]}</p><button id="close">Guardar en el diario</button>`,
    );
    button("close", resume);
  }
  if (o.kind === "save") {
    toast(
      writeSave(state)
        ? "Memoria conservada. Partida guardada."
        : "El navegador no permite guardar. Libera almacenamiento o sal del modo privado.",
    );
  }
  if (o.kind === "door") {
    if (
      o.target === 1 &&
      state.room === 0 &&
      !state.items.includes("Llave de latón")
    ) {
      toast("Cerrada. Necesitas la llave de latón del vestíbulo.");
      return;
    }
    if (
      o.target === 1 &&
      state.room === 0 &&
      !state.items.includes("Medallón Veyr")
    ) {
      toast(
        "La puerta exige el medallón de la caja astronómica. Lee la carta del vestíbulo.",
      );
      return;
    }
    if (o.target === 4 && state.seals.length < 3) {
      toast("El umbral exige los tres sellos. Consulta tu diario.");
      return;
    }
    state.room = o.target!;
    state.x = 0;
    state.z = o.id === "back" ? -5.8 : 5.8;
    state.sanity = clamp(state.sanity - 3);
    loadRoom();
    toast(names[state.room]);
  }
  if (o.kind === "seal") {
    if (
      o.id === "mansion-puzzle"
        ? state.items.includes("Medallón Veyr")
        : state.seals.includes(o.target!)
    ) {
      toast("Este sello ya descansa en tu inventario.");
      return;
    }
    panel(
      `<div class="eyebrow">EL MECANISMO ${o.target! + 1}</div><h2>Una palabra, una ausencia</h2><p>Tres inscripciones rodean la cerradura. Los documentos explican el orden. ¿Qué palabra corresponde a este sello?</p><div class="actions">${["Ceniza", "Marea", "Umbral"].map((s, i) => `<button id="answer${i}">${s}</button>`).join("")}<button id="close">Volver</button></div>`,
    );
    for (let i = 0; i < 3; i++)
      button("answer" + i, () => {
        resume();
        if (i === o.target) {
          if (o.id === "mansion-puzzle") state.items.push("Medallón Veyr");
          else state.seals.push(i);
          toast(
            o.id === "mansion-puzzle"
              ? "Medallón Veyr recuperado. Ya puedes abrir la biblioteca."
              : "Sello recuperado. " + state.seals.length + "/3",
          );
          audio.tone(620, 0.7);
        } else {
          state.sanity = clamp(state.sanity - 12);
          toast("La casa pronuncia tu nombre. Has perdido cordura.");
          audio.tone(65, 0.7, "sawtooth");
        }
      });
    button("close", resume);
  }
  if (o.kind === "end") {
    if (state.seals.length < 3) return;
    state.ended = true;
    panel(
      `<div class="eyebrow">FIN · ${state.sanity >= 40 ? "LA MEMORIA DEL AMANECER" : "LA ÚLTIMA AUSENCIA"}</div><h2>${state.sanity >= 40 ? "Recordar también es dejar ir." : "La casa aprendió tu nombre."}</h2><p>${state.sanity >= 40 ? "Élise quiebra los sellos. Por primera vez, la voz de Adrien parece lejana. Al amanecer, en el tren, una fotografía vuelve a tener dos rostros. Uno de ellos sonríe." : "El intervalo se cierra. En la estación encuentran una maleta y una fotografía sin rostros. En los Alpes, una casa añade una ventana. Detrás, alguien espera una carta."}</p><p>Tiempo: ${Math.floor(state.elapsed / 60)} min · Cordura: ${Math.round(state.sanity)} · Documentos: ${state.read.length}/5</p><button id="finish">Volver al título</button>`,
    );
    button("finish", () => {
      started = false;
      menu();
    });
  }
}
function update(dt: number) {
  const c = input.poll();
  if (input.take("Escape")) {
    menu();
    return;
  }
  if (input.take("Tab")) {
    inventory();
    return;
  }
  if (input.take("KeyM")) {
    panel(
      `<div class="eyebrow">PLANO DEL INTERVALO</div><h2>Cinco estancias, una herida</h2><div id="map">${names.map((n, i) => `<div class="maproom ${i === state.room ? "current" : ""}">${i + 1} · ${n} ${i === state.room ? "← ESTÁS AQUÍ" : ""} ${i === 4 && state.seals.length < 3 ? "· requiere 3 sellos" : ""}</div>`).join("")}</div><p class="small">Las puertas están en los extremos norte y sur. Los escritorios de memoria están al suroeste.</p><button id="close">Volver</button>`,
    );
    button("close", resume);
    return;
  }
  if (input.take("KeyH")) heal();
  if (state.health <= 0) {
    deathTime += dt;
    animateDeath(player, deathTime / 0.85);
    world.shadowBudget.mark(true);
    if (deathTime >= 0.85) {
      panel(
        '<div class="eyebrow">LA CASA CONSERVA OTRO RECUERDO</div><h2>Tu voz se ha apagado.</h2><p>Puedes recuperar la última memoria guardada o volver a empezar.</p><div class="actions"><button id="retry">Reintentar</button><button id="title">Título</button></div>',
      );
      button("retry", () => begin(readSave() ?? fresh()));
      button("title", menu);
    }
    return;
  }
  // Stable world axes prevent reversed input when the cinematic framing changes.
  yaw = 0;
  let x = c.x,
    z = c.z;
  const len = Math.hypot(x, z);
  if (len > 1) {
    x /= len;
    z /= len;
  }
  const speed = c.guard ? 1.2 : c.run ? 4.1 : 2.7,
    dx = (x * Math.cos(yaw) + z * Math.sin(yaw)) * speed * dt,
    dz = (-x * Math.sin(yaw) + z * Math.cos(yaw)) * speed * dt;
  const p = move(state.x, state.z, dx, dz, world.obstacles);
  state.x = p.x;
  state.z = p.z;
  player.position.set(p.x, 0, p.z);
  if (len > 0.1) {
    player.rotation.y = Math.atan2(dx, dz);
    if (state.elapsed - audio.lastStep > 0.43) {
      audio.tone(75, 0.07, "triangle");
      audio.lastStep = state.elapsed;
    }
  }
  contact[0].position.copy(player.position).setY(0.025);
  contact[1].position.copy(enemy.position).setY(0.025);
  threat.position.copy(enemy.position).setY(0.035);
  threat.visible =
    enemy.visible && enemy.position.distanceTo(player.position) < 2.8;
  (threat.material as T.MeshBasicMaterial).opacity =
    combat.windup > 0 ? 0.3 : 0.09;
  const wasAlive = enemy.visible;
  combat.update(
    dt,
    state,
    player,
    enemy,
    world.obstacles,
    input.take("Space"),
    (f, d) => audio.tone(f, d, "triangle"),
    toast,
    c.guard,
  );
  if (wasAlive && !enemy.visible) {
    corpse.position.copy(enemy.position);
    corpse.rotation.copy(enemy.rotation);
    corpse.visible = true;
    corpseTime = 0;
  }
  if (corpse.visible) {
    corpseTime += dt;
    animateDeath(corpse, corpseTime / 0.8);
    world.shadowBudget.mark(corpseTime < 1);
  }
  el("hit-feedback").style.opacity = String(
    combat.hurt > 0 ? (combat.guarding ? 0.18 : 0.36) : 0,
  );
  el("hit-feedback").classList.toggle("blocked", combat.guarding);
  audio.ambient(state.elapsed, state.sanity);
  animateCharacter(
    player,
    state.elapsed,
    len > 0.1,
    combat.animation,
    c.guard,
    combat.hurt,
    c.run,
    dt,
  );
  world.shadowBudget.mark(
    len > 0.1 ||
      combat.animation > 0 ||
      combat.windup > 0 ||
      combat.hurt > 0 ||
      c.guard !== world.guardPose ||
      Math.hypot(
        enemy.position.x - world.lastEnemyX,
        enemy.position.z - world.lastEnemyZ,
      ) > 0.001 ||
      enemy.visible !== world.lastEnemyVisible,
  );
  world.guardPose = c.guard;
  world.lastEnemyX = enemy.position.x;
  world.lastEnemyZ = enemy.position.z;
  world.lastEnemyVisible = enemy.visible;
  cinematic.update(
    camera,
    state.x,
    state.z,
    state.room,
    dt,
    settings.reduced,
    world.obstacles,
    {
      mode: settings.cameraMode,
      enemy: enemy.position,
      combat: enemy.visible && enemy.position.distanceTo(player.position) < 2.8,
    },
  );
  near = world.objects
    .filter((o) => Math.hypot(o.x - state.x, o.z - state.z) < 1.9)
    .sort(
      (a, b) =>
        Math.hypot(a.x - state.x, a.z - state.z) -
        Math.hypot(b.x - state.x, b.z - state.z),
    )[0];
  world.highlight.visible = Boolean(near);
  if (near) world.highlight.position.set(near.x, 0.075, near.z);
  world.atmosphere.update(dt, state.elapsed, settings.reduced);
  el("prompt").style.display = near ? "block" : "none";
  el("prompt").textContent = near ? "E / A · " + near.name : "";
  if (input.take("KeyE") && near) interact(near);
  state.elapsed += dt;
  el("health").style.width = state.health + "%";
  el("sanity").style.width = state.sanity + "%";
  el("hptext").textContent = String(Math.ceil(state.health));
  el("sptext").textContent = String(Math.ceil(state.sanity));
  el("veil").style.opacity = String(
    sanity.update(state, world, settings.reduced, toast, () =>
      audio.tone(98, 1.5),
    ),
  );
}
let last = performance.now();
let nextMenuMove = 0;
function frame(now: number) {
  requestAnimationFrame(frame);
  const interval = now - last;
  const dt = Math.min(interval / 1000, 0.2);
  last = now;
  if (started && !paused) {
    const steps = Math.max(1, Math.ceil(dt / 0.025));
    for (let i = 0; i < steps && !paused; i++) update(dt / steps);
  } else {
    const nav = input.poll();
    if (Math.abs(nav.z) > 0.4 && now > nextMenuMove) {
      const controls = Array.from(
        el("panel").querySelectorAll<HTMLElement>(
          "button:not(:disabled),input,select",
        ),
      );
      const i = controls.indexOf(document.activeElement as HTMLElement);
      controls[
        (i + (nav.z > 0 ? 1 : -1) + controls.length) % controls.length
      ]?.focus();
      nextMenuMove = now + 220;
    }
    if (input.take("Space") && started && !state.ended) resume();
    if (input.take("Escape") && started && !state.ended) resume();
    if (input.take("KeyE")) {
      const b = el("panel").querySelector<HTMLButtonElement>("button:focus");
      b?.click();
    }
    if (input.take("Tab") && started && !state.ended) resume();
  }
  if (!started && world) {
    camera.position.set(Math.sin(now * 0.00008) * 3, 3.2, 6.7);
    camera.lookAt(0, 1, -2);
  }
  if (toastTime > 0 && !paused) {
    toastTime -= dt;
    if (toastTime <= 0) el("toast").textContent = "";
  }
  input.end();
  if (world) {
    world.shadowBudget.apply(world.shadowLight, now);
    const start = performance.now();
    gpuTimer?.begin();
    renderer.render(world.scene, camera);
    gpuTimer?.end();
    if (started && !paused) metrics.record(interval, performance.now() - start);
  }
}
loadRoom();
menu();
requestAnimationFrame(frame);
addEventListener("resize", () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  applyQuality(renderer, settings.quality);
});
addEventListener("blur", () => {
  if (started && !paused) menu();
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden && started && !paused) menu();
});
export function inspect() {
  return {
    state: structuredClone(state),
    paused,
    camera: camera.position.toArray(),
    target: player.position.toArray(),
    combat: {
      enemyHealth: combat.health,
      windup: combat.windup,
      guarding: combat.guarding,
      animation: combat.animation,
    },
    cinematicZone: cinematic.zone,
    cameraMode: settings.cameraMode,
    corpse: { visible: corpse.visible, progress: corpseTime },
    cameraCorrected: cinematic.corrected,
    cameraQuaternion: camera.quaternion.toArray(),
    cameraFov: camera.fov,
    quality: qualityProfile(settings.quality),
    performance: metrics.snapshot(),
    gpuTime: gpuTimer?.snapshot(),
    memory: renderer.info.memory,
    textures: textureBudget(),
    playerRig: Boolean(player.userData.rig),
    limbPose: player.userData.rig?.leftLeg.rotation.x,
    enemy: { position: enemy.position.toArray(), visible: enemy.visible },
    draw: renderer.info.render,
    canvas: {
      width: renderer.domElement.width,
      height: renderer.domElement.height,
      rect: renderer.domElement.getBoundingClientRect().toJSON(),
    },
    objects: world.scene.children.length,
  };
}
// Read-only browser test observer. Vite removes this branch from production.
if (import.meta.env.DEV) {
  Object.defineProperty(window, "sanityInspect", {
    value: inspect,
    configurable: true,
  });

  Object.defineProperty(window, "sanityResetMetrics", {
    value: () => { metrics.clear(); gpuTimer?.reset(); },
    configurable: true,
  });
}
