import * as T from "three";
import { animateCharacter } from "../world/character";
import { clamp, damage, move, type State, type Obstacle } from "./state";
/** Segment/AABB at chest height: low carpets do not block a strike, furniture does. */
export function strikeClear(a: T.Vector3, b: T.Vector3, obstacles: Obstacle[]) {
  const start = a.clone().setY(1.05),
    end = b.clone().setY(1.05);
  const delta = end.clone().sub(start),
    length = delta.length();
  if (length < 0.001) return true;
  const ray = new T.Ray(start, delta.normalize()),
    hit = new T.Vector3();
  return !obstacles.some((o) => {
    const box = new T.Box3(
      new T.Vector3(o.x - o.w / 2, 0, o.z - o.d / 2),
      new T.Vector3(o.x + o.w / 2, o.height ?? 2, o.z + o.d / 2),
    );
    return !!ray.intersectBox(box, hit) && hit.distanceTo(start) <= length;
  });
}
export class Combat {
  enemyHurt = 0;
  impact = 0;
  health = 60;
  enemyCooldown = 1;
  attackCooldown = 0;
  animation = 0;
  windup = 0;
  hurt = 0;
  guarding = false;
  constructor(room: number) {
    this.health += room * 10;
  }
  update(
    dt: number,
    state: State,
    player: T.Group,
    enemy: T.Group,
    obstacles: Obstacle[],
    attack: boolean,
    onSound: (frequency: number, duration: number) => void,
    onMessage: (text: string) => void,
    guard = false,
  ) {
    this.guarding = guard;
    this.enemyHurt = Math.max(0, this.enemyHurt - dt);
    this.impact = Math.max(0, this.impact - dt);
    this.hurt = Math.max(0, this.hurt - dt);
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    this.enemyCooldown -= dt;
    this.animation = Math.max(0, this.animation - dt);
    if (attack && !guard && this.attackCooldown === 0) {
      this.attackCooldown = 0.65;
      this.animation = 0.3;
      onSound(150, 0.15);
      if (
        enemy.visible &&
        enemy.position.distanceTo(player.position) < 1.9 &&
        strikeClear(player.position, enemy.position, obstacles)
      ) {
        this.health -= 30;
        this.enemyHurt = 0.35;
        this.impact = 0.18;
        onSound(92, 0.12);
        state.sanity = clamp(state.sanity + 2);
        const knock = enemy.position
          .clone()
          .sub(player.position)
          .normalize()
          .multiplyScalar(0.4);
        const p = move(
          enemy.position.x,
          enemy.position.z,
          knock.x,
          knock.z,
          obstacles,
        );
        enemy.position.set(p.x, 0, p.z);
        if (this.health <= 0) {
          enemy.visible = false;
          state.defeated.push("enemy" + state.room);
          onMessage("La sombra se deshace. La casa guarda silencio.");
        }
      }
    }
    if (!enemy.visible) {
      state.sanity = clamp(state.sanity + dt * 0.35);
      return;
    }
    const dist = enemy.position.distanceTo(player.position);
    if (dist < 8 && dist > 1.1) {
      const d = player.position
        .clone()
        .sub(enemy.position)
        .normalize()
        .multiplyScalar((0.85 + state.room * 0.08) * dt);
      let p = move(enemy.position.x, enemy.position.z, d.x, d.z, obstacles);
      if (Math.hypot(p.x - enemy.position.x, p.z - enemy.position.z) < 0.001) {
        p = move(enemy.position.x, enemy.position.z, -d.z, d.x, obstacles);
      }
      enemy.position.set(p.x, 0, p.z);
      enemy.lookAt(player.position);
    }
    if (this.windup > 0) {
      this.windup -= dt;
      if (this.windup <= 0) {
        if (
          dist < 1.8 &&
          strikeClear(enemy.position, player.position, obstacles)
        ) {
          damage(state, guard ? 3 : 12);
          this.hurt = 0.3;
          onSound(guard ? 200 : 48, 0.25);
          onMessage(
            guard
              ? "Desvías el golpe. La defensa amortigua el daño."
              : "La sombra te alcanza. Mantén F / LB para defender.",
          );
        }
        this.enemyCooldown = 1.5;
      }
    } else if (
      dist < 1.5 &&
      this.enemyCooldown <= 0 &&
      strikeClear(enemy.position, player.position, obstacles)
    ) {
      this.windup = 0.42;
      onMessage("La sombra levanta las garras…");
    }
    animateCharacter(
      enemy,
      state.elapsed,
      dist > 1.5,
      this.windup > 0 ? 0.3 * (1 - this.windup / 0.42) : 0,
      false,
      this.enemyHurt,
      false,
      dt,
    );
    if (dist < 5) state.sanity = clamp(state.sanity - dt * 0.6);
  }
}
