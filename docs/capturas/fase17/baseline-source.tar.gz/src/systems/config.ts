export interface Settings {
  reduced: boolean;
  volume: number;
  quality: number;
  cameraMode: "classic" | "modern";
}
export function readSettings(): Settings {
  const defaults: Settings = {
    reduced: matchMedia("(prefers-reduced-motion: reduce)").matches,
    volume: 0.35,
    quality: 1.3,
    cameraMode: "classic",
  };
  try {
    const s = JSON.parse(localStorage.getItem("sanity404-settings") || "{}");
    return {
      reduced: typeof s.reduced === "boolean" ? s.reduced : defaults.reduced,
      volume:
        typeof s.volume === "number" && Number.isFinite(s.volume)
          ? Math.max(0, Math.min(1, s.volume))
          : defaults.volume,
      cameraMode: s.cameraMode === "modern" ? "modern" : "classic",
      quality: [1, 1.3, 1.6].includes(s.quality) ? s.quality : defaults.quality,
    };
  } catch {
    return defaults;
  }
}
