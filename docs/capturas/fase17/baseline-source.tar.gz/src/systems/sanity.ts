import * as T from "three";
import type { State } from "./state";
import { character, type World } from "../world/scene";
export class Sanity {
  apparition: T.Group;
  private nextEvent = 20;
  private until = 0;
  constructor(world: World) {
    this.apparition = character(true);
    this.apparition.visible = false;
    world.scene.add(this.apparition);
  }
  update(
    state: State,
    world: World,
    reduced: boolean,
    notify: (s: string) => void,
    sound: () => void,
  ) {
    const intensity = 1 - state.sanity / 100;
    world.lights.forEach((l, i) => {
      const base = Number(l.userData.base ?? l.intensity);
      l.userData.base = base;
      l.intensity =
        base *
        (reduced
          ? 1
          : 1 + Math.sin(state.elapsed * 0.6 + i) * 0.08 * intensity);
    });
    this.apparition.visible = !reduced && state.elapsed < this.until;
    if (state.elapsed >= this.nextEvent) {
      this.nextEvent = state.elapsed + 24;
      if (state.sanity < 55) {
        notify(
          state.sanity < 30
            ? "Una ventana recuerda un cielo que nunca existió."
            : "Has oído tus propios pasos al otro lado de la pared.",
        );
        if (!reduced) {
          this.until = state.elapsed + 1.4;
          this.apparition.position.set(state.x + 2.5, 0, state.z - 3);
          sound();
        }
      }
    }
    return reduced ? 0.5 : 0.55 + intensity * 0.45;
  }
}
