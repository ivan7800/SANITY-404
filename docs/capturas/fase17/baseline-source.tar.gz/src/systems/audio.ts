export class Audio {
  ctx?: AudioContext;
  gain?: GainNode;
  volume = 0.35;
  lastStep = 0;
  private nextAmbient = 7;
  async start() {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.gain = this.ctx.createGain();
      this.gain.gain.value = this.volume;
      this.gain.connect(this.ctx.destination);
      // Original filtered wind, generated once; no external audio assets.
      const buffer = this.ctx.createBuffer(
        1,
        this.ctx.sampleRate * 2,
        this.ctx.sampleRate,
      );
      const samples = buffer.getChannelData(0);
      let seed = 404;
      for (let i = 0; i < samples.length; i++) {
        seed = (seed * 1664525 + 1013904223) >>> 0;
        samples[i] = seed / 2147483648 - 1;
      }
      const wind = this.ctx.createBufferSource(),
        filter = this.ctx.createBiquadFilter(),
        level = this.ctx.createGain();
      wind.buffer = buffer;
      wind.loop = true;
      filter.type = "lowpass";
      filter.frequency.value = 260;
      level.gain.value = 0.035;
      wind.connect(filter);
      filter.connect(level);
      level.connect(this.gain);
      wind.start();
      for (const f of [55, 82.41, 110.3]) {
        const o = this.ctx.createOscillator(),
          g = this.ctx.createGain();
        o.type = "sine";
        o.frequency.value = f;
        g.gain.value = 0.035;
        o.connect(g);
        g.connect(this.gain);
        o.start();
      }
    }
    await this.ctx.resume();
  }
  tone(f = 180, d = 0.15, type: OscillatorType = "sine") {
    if (!this.ctx || !this.gain) return;
    const o = this.ctx.createOscillator(),
      g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, this.ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(
      f * 0.55,
      this.ctx.currentTime + d,
    );
    g.gain.setValueAtTime(0.15, this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + d);
    o.connect(g);
    g.connect(this.gain);
    o.start();
    o.stop(this.ctx.currentTime + d);
    o.onended = () => {
      o.disconnect();
      g.disconnect();
    };
  }
  ambient(time: number, sanity: number) {
    if (time < this.nextAmbient) return;
    this.nextAmbient = time + 9 + Math.sin(time) * 2;
    // Slow wood creak; interval and pitch respond to sanity without sudden peaks.
    this.tone(125 + sanity * 0.35, 0.65, "triangle");
  }
  setVolume(v: number) {
    this.volume = v;
    if (this.gain && this.ctx)
      this.gain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.1);
  }
  pause() {
    void this.ctx?.suspend();
  }
  resume() {
    void this.ctx?.resume();
  }
}
