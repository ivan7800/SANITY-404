import * as T from "three";
import { ShadowBudget } from "../render/shadow-budget";
import { batchRigid } from "../render/batch";
import { pbr } from "../render/materials";
import { Atmosphere } from "../render/atmosphere";
import { lightScene } from "../render/lighting";
import { qualityProfile } from "../render/quality";
import { prop } from "./props";
import { mansion } from "./mansion";
export { character } from "./character";
import type { Obstacle } from "../systems/state";
export const names = [
  "Mansión Veyr",
  "Biblioteca prohibida",
  "Cripta de los nombres",
  "Capilla del silencio",
  "Ruinas del intervalo",
];
export const subtitles = [
  "ALPES EUROPEOS · NOVIEMBRE DE 1927",
  "NINGÚN LIBRO RECUERDA A SU AUTOR",
  "LOS MUERTOS NO ESTÁN SOLOS",
  "AQUÍ SE REZA HACIA ABAJO",
  "UN LUGAR ANTERIOR AL TIEMPO",
];
export interface Interactable {
  id: string;
  name: string;
  x: number;
  z: number;
  kind: "note" | "item" | "door" | "seal" | "save" | "end";
  value?: string;
  target?: number;
  mesh?: T.Object3D;
}
export class World {
  scene = new T.Scene();
  obstacles: Obstacle[] = [];
  objects: Interactable[] = [];
  lights: T.PointLight[] = [];
  private materials = new Map<string, T.MeshStandardMaterial>();
  atmosphere: Atmosphere;
  highlight: T.Mesh;
  shadowLight: T.SpotLight;
  shadowBudget: ShadowBudget;
  guardPose = false;
  lastEnemyX = 0;
  lastEnemyZ = 0;
  lastEnemyVisible = true;
  constructor(
    public room: number,
    items: string[],
    seals: number[],
    read: string[],
    collected: string[] = [],
    quality = 1.3,
  ) {
    const scene = this.scene;
    scene.background = new T.Color("#111817");
    scene.fog = new T.FogExp2("#17202a", 0.022);
    scene.add(new T.HemisphereLight(0xb1c3d4, 0x33302b, 1.1));
    const wall =
      room === 0
        ? 0x343c35
        : room === 1
          ? 0x323331
          : room === 3
            ? 0x393e3b
            : 0x353c3d;
    this.box(0, -0.25, 0, 16, 0.5, 16, 0x333532, false);
    this.box(0, 2.5, -8, 16, 5, 0.35, wall);
    this.box(-8, 2.5, 0, 0.35, 5, 16, wall);
    this.box(8, 2.5, 0, 0.35, 5, 16, wall);
    this.box(0, 2.5, 8, 16, 5, 0.35, wall);
    for (let i = -7; i <= 7; i += 2) {
      this.box(i, 0.01, 0, 0.025, 0.015, 16, 0x171e1a, false);
      this.box(0, 0.012, i, 16, 0.015, 0.025, 0x171e1a, false);
      this.box(i, 2.4, -7.72, 0.16, 4.8, 0.14, 0x686555, false);
      this.box(i, 4.5, -7.65, 1.8, 0.12, 0.18, 0x77705b, false);
    }
    this.box(
      0,
      0.025,
      0,
      3.5,
      0.025,
      12,
      room === 0 ? 0x502f2b : 0x273732,
      false,
    );
    for (const x of [-6.8, 6.8])
      for (const z of [-5, 3]) {
        this.box(x, 1.6, z, 0.4, 3.2, 0.4, 0x666654);
        this.lamp(x, 3.1, z, 0xffbd80, 7);
      }
    if (room === 0) {
      scene.add(mansion(this.obstacles));
      this.obstacles.push(
        { x: -4, z: -2, w: 3, d: 1.6, height: 1.5 },
        { x: 4, z: 1, w: 2, d: 3, height: 1.5 },
      );
    }
    if (room === 1) {
      for (const x of [-5, 5])
        for (const z of [-3, 2]) {
          this.box(x, 1.7, z, 1, 3.4, 3.8, 0x30281d);
          for (let i = 0; i < 14; i++)
            this.box(
              x + (x < 0 ? 0.55 : -0.55),
              0.4 + (i % 4) * 0.75,
              z - 1.6 + Math.floor(i / 4) * 0.8,
              0.15,
              0.55,
              0.4,
              [0x625338, 0x3e5146, 0x69433c][i % 3],
              false,
            );
        }
    }
    if (room === 2) {
      for (const x of [-4, 4])
        for (const z of [-3, 2]) {
          this.box(x, 0.55, z, 1.5, 1.1, 2.7, 0x575951);
          this.box(x, 1.14, z, 1.7, 0.15, 2.9, 0x777b6f, false);
        }
    }
    if (room === 3) {
      for (const x of [-4, 4])
        for (const z of [-3, 0, 3]) this.box(x, 0.5, z, 2.5, 1, 0.65, 0x393025);
      this.box(3, 0.8, -5, 3, 1.6, 1.3, 0x707263);
      this.box(0, 3.6, -7.6, 0.3, 2, 0.2, 0xa49a78, false);
      this.box(0, 3.8, -7.6, 1.4, 0.25, 0.2, 0xa49a78, false);
    }
    if (room === 4) {
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
        const p = this.box(
          Math.cos(a) * 5,
          1.7,
          Math.sin(a) * 5,
          0.8,
          3.4,
          0.8,
          0x52605a,
        );
        p.rotation.z = Math.sin(i) * 0.2;
      }
      const ring = new T.Mesh(
        new T.TorusGeometry(1.7, 0.12, 6, 36),
        new T.MeshStandardMaterial({
          color: 0x8baf9d,
          emissive: 0x336959,
          emissiveIntensity: 1,
        }),
      );
      ring.position.set(0, 2, -3);
      scene.add(ring);
      this.lamp(0, 2, -3, 0x72e8c0, 35);
    }
    this.add(
      {
        id: "save" + room,
        name: "Escritorio de memoria · guardar",
        x: -2,
        z: 5,
        kind: "save",
      },
      0x8b7753,
    );
    this.add(
      {
        id: "note" + room,
        name: "Leer documento",
        x: -5.5,
        z: 5,
        kind: "note",
      },
      0xc5ba92,
    );
    if (room === 0 && !items.includes("Llave de latón"))
      this.add(
        {
          id: "key",
          name: "Recoger llave de latón",
          x: -4,
          z: -0.5,
          kind: "item",
          value: "Llave de latón",
        },
        0xc2a15b,
      );
    if (room < 4 && !collected.includes("Tónico " + room))
      this.add(
        {
          id: "tonic" + room,
          name: "Recoger tónico",
          x: 5.8,
          z: 5.5,
          kind: "item",
          value: "Tónico " + room,
        },
        0x76a99a,
      );
    if (room > 0)
      this.add(
        {
          id: "back",
          name: "Volver · " + names[room - 1],
          x: 0,
          z: 7,
          kind: "door",
          target: room - 1,
        },
        0x756749,
      );
    if (room < 4)
      this.add(
        {
          id: "next",
          name: "Abrir · " + names[room + 1],
          x: 0,
          z: -7,
          kind: "door",
          target: room + 1,
        },
        0x756749,
      );
    if (room === 0)
      this.add(
        {
          id: "mansion-puzzle",
          name: "Examinar caja astronómica",
          x: 3,
          z: 4,
          kind: "seal",
          target: 0,
        },
        0xa38d5e,
      );
    if (room >= 1 && room <= 3)
      this.add(
        {
          id: "seal" + room,
          name: "Examinar mecanismo del sello",
          x: 0,
          z: -4.5,
          kind: "seal",
          target: room - 1,
        },
        seals.includes(room - 1) ? 0x427b60 : 0x968b6a,
      );
    if (room === 4)
      this.add(
        { id: "end", name: "Cerrar el intervalo", x: 0, z: -3, kind: "end" },
        0x9dd9c0,
      );
    const staticGroup = new T.Group();
    for (const object of [...scene.children])
      if (object.userData.staticBox) staticGroup.add(object);
    batchRigid(staticGroup);
    scene.add(staticGroup);
    this.shadowLight = lightScene(scene, quality);
    this.shadowBudget = new ShadowBudget(quality);
    this.atmosphere = new Atmosphere(scene, qualityProfile(quality).dust);
    this.highlight = new T.Mesh(
      new T.TorusGeometry(0.45, 0.014, 6, 32),
      new T.MeshBasicMaterial({
        color: 0xdcc891,
        transparent: true,
        opacity: 0.7,
        depthWrite: false,
      }),
    );
    this.highlight.rotation.x = -Math.PI / 2;
    this.highlight.visible = false;
    scene.add(this.highlight);
    void read;
  }
  box(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    color: number,
    solid = true,
  ) {
    const surface = h < 0.05 && w > 2 ? "fabric" : h > 3 ? "plaster" : "stone";
    const key = surface + color;
    let material = this.materials.get(key);
    if (!material) {
      material = pbr(surface, color);
      this.materials.set(key, material);
    }
    const m = new T.Mesh(new T.BoxGeometry(w, h, d), material);
    m.userData.staticBox = true;
    m.position.set(x, y, z);
    m.castShadow = true;
    m.receiveShadow = true;
    this.scene.add(m);
    if (solid) this.obstacles.push({ x, z, w, d, height: h });
    return m;
  }
  lamp(x: number, y: number, z: number, color: number, intensity: number) {
    const l = new T.PointLight(color, intensity, 10, 2);
    l.position.set(x, y, z);
    this.scene.add(l);
    this.lights.push(l);
    const b = new T.Mesh(
      new T.SphereGeometry(0.09, 6, 6),
      new T.MeshBasicMaterial({ color }),
    );
    b.position.copy(l.position);
    b.visible = false;
    this.scene.add(b);
  }
  add(o: Interactable, color: number) {
    const m = prop(o.kind, o.id, color);
    m.position.set(o.x, 0, o.z);
    this.scene.add(m);
    o.mesh = m;
    this.objects.push(o);
  }
  dispose() {
    const geometries = new Set<T.BufferGeometry>(),
      materials = new Set<T.Material>();
    this.scene.traverse((o) => {
      if (o instanceof T.Mesh || o instanceof T.Points) {
        geometries.add(o.geometry);
        for (const m of Array.isArray(o.material) ? o.material : [o.material])
          materials.add(m);
      }
      if (o instanceof T.Light && "shadow" in o)
        (o as T.SpotLight).shadow?.map?.dispose();
    });
    for (const g of geometries) g.dispose();
    for (const m of materials) m.dispose();
  }
}
