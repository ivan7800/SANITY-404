export const notes = [
  [
    "Carta sin remitente",
    "Élise: si encuentras esta casa, aún me recuerdas. En 1927 Veyr dejó de figurar en los mapas. Yo dejé de figurar en las fotografías. La llave descansa junto al escritorio del vestíbulo. La caja astronómica guarda el medallón: elige lo que queda después del fuego, CENIZA. Inés escribió lo mismo en 1610; el cantero Lucan lo talló en el siglo IV. Tres épocas, una sola herida. — Adrien.",
  ],
  [
    "Catálogo de ausencias",
    "El bibliotecario anotó tres palabras: CENIZA, MAREA, UMBRAL. «Primero arde lo que fuimos. Después regresa lo que perdimos. Finalmente cruzamos». El primer sello exige el comienzo.",
  ],
  [
    "Registro del sepulturero",
    "Enterramos siete cuerpos y escuchamos ocho respiraciones. El segundo sello exige aquello que regresa. No leas nombres en voz alta: aquí cada nombre abre una boca.",
  ],
  [
    "Última homilía",
    "No era un dios. Era el espacio entre dos recuerdos. El tercer sello exige lo que cruzamos. Para cerrar el intervalo, devuelve los tres sellos. Si aún recuerdas quién eres, podrás recordar a tu hermano.",
  ],
  [
    "La voz de Adrien",
    "No intentes traerme de vuelta. La casa necesita que alguien la recuerde para existir. Rompe el círculo. Vive lo suficiente para olvidarme.",
  ],
];
